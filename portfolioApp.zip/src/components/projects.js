const projects = [
    {
        id: 0,
        title: "Elite Pharmacy Inc",
        url: "https://picsum.photos/800/487?random=1",
        desc: "This is a project based in HTML, CSS and jQuery"
    },
    {
        id: 1,
        title: "TMP Handyman",
        url: "https://picsum.photos/800/487?random=2",
        desc: "This is a project based in HTML, CSS and jQuery"
    },
    {
        id: 2,
        title: "PurshAnn",
        url: "https://picsum.photos/800/487?random=3",
        desc: "This is a project based in HTML, CSS and jQuery"
    },
    {
        id: 3,
        title: "Pool Services",
        url: "https://picsum.photos/800/487?random=4",
        desc: "This is a project based in HTML, CSS and jQuery"
    }
]

export default projects;